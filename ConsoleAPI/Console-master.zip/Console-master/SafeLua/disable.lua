print("Disabled")
